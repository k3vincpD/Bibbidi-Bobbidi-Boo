package Logic;

import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

public class Flapper extends Ballom{
    public Flapper(Point2D.Float position, BufferedImage[][] spriteMap) {
        super(position, spriteMap);
        update();
        updateSprite();
        updateDeadSprite();

        this.moveSpeed = 3.0F;
    }
}
