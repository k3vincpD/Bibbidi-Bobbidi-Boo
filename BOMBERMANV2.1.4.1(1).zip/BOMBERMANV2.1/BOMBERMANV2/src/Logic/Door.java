package Logic;

import presentation.ResourceCollection;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class Door extends GameObject{

    public static boolean matchSet;
    private Bomber player;
    private BufferedImage[][] sprite;

    public Door(Point2D.Float position, BufferedImage image) {
        super(position, image);
        this.collider = new Rectangle2D.Float(position.x + 8, position.y + 8, this.width - 16, this.height - 16);
        this.matchSet = false;
    }

    @Override
    public void onCollisionEnter(GameObject collidingObj) {
        collidingObj.handleCollision(this);
    }

    @Override
    public void handleCollision(Bomb collidingObj) {

    }

    @Override
    public void handleCollision(Bomber collidingObj){
        matchSet = true;
    }


}
