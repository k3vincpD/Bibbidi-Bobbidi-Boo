package Logic;

import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

public class Nagacham extends Pass{

    public Nagacham(Point2D.Float position, BufferedImage[][] spriteMap, Bomber target) {
        super(position, spriteMap, target);
        update();
        checkChaseCondition();
        updateSprite();
        updateDeadSprite();
        this.moveSpeed = 2.5F;
    }


}
