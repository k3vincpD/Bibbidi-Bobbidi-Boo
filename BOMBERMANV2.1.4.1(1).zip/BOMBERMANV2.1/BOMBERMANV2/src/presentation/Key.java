package presentation;

public class Key {

    public static Key up = new Key();       // Up movement
    public static Key down = new Key();     // Down movement
    public static Key left = new Key();     // Left movement
    public static Key right = new Key();    // Right movement
    public static Key action = new Key();   // Place bomb

}