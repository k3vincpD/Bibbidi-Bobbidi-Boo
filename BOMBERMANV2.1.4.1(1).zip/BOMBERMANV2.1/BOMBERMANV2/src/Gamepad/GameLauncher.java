package Gamepad;

import presentation.*;


/*
 * Contains the main method to launch the game.
 */
public class GameLauncher {
    //todo: hacer que unicamente aparezca una unica vez la puerta , tambien hacer que no aparezcan en la misma posicion
    // o que el sprit de la puerta sea mas grande que el del power up, y que si toca la explocion con la puerta dnere 3 nuevos enemigos
    // mejorar el sprit de la puerta

    // The one and only window for the game to run
    public static GameWindow window;

    public static void main(String[] args) {
        ResourceCollection.readFiles();
        ResourceCollection.init();

        GamePanel game;
        try {
            game = new GamePanel(args[0]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println(e + ": Program args not given");
            game = new GamePanel("/resources/Proto1.csv"); //poner un mapo
        }

        game.init();
        window = new GameWindow(game);

        System.gc();
    }

}


